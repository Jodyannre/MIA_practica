--Conteos de tablas

SELECT COUNT(id_pais) as pais FROM PAIS; 
SELECT COUNT(id_categoria) as categoria FROM CATEGORIA;
SELECT COUNT(id_idioma) as idioma FROM IDIOMA;
SELECT COUNT(id_clasificacion) as clasificacion FROM CLASIFICACION;
SELECT COUNT(id_actor) as actor FROM ACTOR;
SELECT COUNT(id_ciudad) as ciudad FROM CIUDAD;
SELECT COUNT(id_pelicula) as pelicula FROM PELICULA;
SELECT COUNT(id_elenco) as elenco FROM ELENCO;
SELECT COUNT(id_detalle_categoria) as detalle_categoria FROM DETALLE_CATEGORIA;
SELECT COUNT(id_traduccion) as traduccion FROM TRADUCCION;
SELECT COUNT(id_direccion) as direccion FROM DIRECCION;
SELECT COUNT(id_tienda) as tienda FROM TIENDA;
SELECT COUNT(id_inventario) as inventario FROM INVENTARIO;
SELECT COUNT(id_empleado) as empleado FROM EMPLEADO;
SELECT COUNT(id_cliente) as cliente FROM CLIENTE;
SELECT COUNT(id_renta) as renta FROM RENTA;



